<?php

$DIR_ROOT =	'./';
include('./slfx_config.php');

	selector();

?>
