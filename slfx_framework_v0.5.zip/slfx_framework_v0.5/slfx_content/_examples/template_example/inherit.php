<?php

/* used for code coloring */
$find_arry = array(
	'style="color: #000000"',
	'style="color: #007700"',
	'style="color: #0000BB"',
	'style="color: #FF8000"',
	'style="color: #DD0000"',
	'style="color: #000000"',
	'style="color: #000000"'
);


$replace_arry = array(
	'class="code-container"',
	'class="color-reserved"',
	'class="color-special"',
	'class="color-comment"',
	'class="color-string"'
);

?>
